SQLite 3

SQLite is a software library that implements a self-contained,
serverless, zero-configuration, transactional SQL database engine.
SQLite is the most widely deployed SQL database engine in the world. The
source code for SQLite is in the public domain.

Homepage: http://sqlite.org/

Copyright: Public Domain

License:
 The author disclaims copyright to this source code.  In place of
 a legal notice, here is a blessing:
 .
 May you do good and not evil.
 May you find forgiveness for yourself and forgive others.
 May you share freely, never taking more than you give.

Version: 3.7.13 (3071300) amalgamation
