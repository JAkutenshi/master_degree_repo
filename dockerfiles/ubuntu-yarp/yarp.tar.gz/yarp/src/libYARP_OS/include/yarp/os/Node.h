/*
 * Copyright (C) 2013 Istituto Italiano di Tecnologia (IIT)
 * Authors: Paul Fitzpatrick
 * CopyPolicy: Released under the terms of the LGPLv2.1 or later, see LGPL.TXT
 */

#ifndef YARP_OS_NODE_H
#define YARP_OS_NODE_H

#include <yarp/os/Contactables.h>
#include <yarp/conf/compiler.h>

namespace yarp {
    namespace os {
        class Node;
    }
}


class YARP_OS_API yarp::os::Node : public Contactables
{
public:
    Node();
    Node(const ConstString& name);
    virtual ~Node();

    virtual void add(Contactable& contactable) override;
    virtual void update(Contactable& contactable);
    virtual void remove(Contactable& contactable) override;

    virtual Contact query(const ConstString& name,
                          const ConstString& category = "") override;

    virtual Contact where();

    void interrupt();

    virtual void prepare(const ConstString& name);
private:
    class Helper;
    Helper * const mPriv;
};

#endif // YARP_OS_NODE_H
