#ifndef UTILMM_CONFIGFILE_SHELL_EXPAND_HH
#define UTILMM_CONFIGFILE_SHELL_EXPAND_HH

#include <string>

namespace utilmm
{
    std::string shell_expand(std::string const& text);
}

#endif

