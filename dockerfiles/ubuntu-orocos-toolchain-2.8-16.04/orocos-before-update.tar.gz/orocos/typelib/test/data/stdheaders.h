#include <sys/time.h>
#include <time.h>
#include <stdint.h>

// Cannot import stdio.h: forward declarations
// #include <stdio.h>

// Cannot import stdlib.h: nested type definitions
// #include <stdlib.h>

