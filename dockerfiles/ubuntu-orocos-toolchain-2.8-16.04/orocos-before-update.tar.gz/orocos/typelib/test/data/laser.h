namespace Laser
{
    typedef int array_typedef[256];
    struct Data
    {
	int sec;
	unsigned int usec;

	double ranges[256];
    };
}

