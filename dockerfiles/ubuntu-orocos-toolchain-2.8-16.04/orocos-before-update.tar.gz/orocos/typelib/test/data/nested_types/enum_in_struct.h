struct Root {
    enum Bla {
        VALUE = 5
    };
};

