class Context
{
private:
    class PrivateClass
    {
    public:
        int field;
    };
    enum PrivateEnum
    {
        VALUE = 10
    };
    typedef PrivateClass PrivateTypedef;
};
