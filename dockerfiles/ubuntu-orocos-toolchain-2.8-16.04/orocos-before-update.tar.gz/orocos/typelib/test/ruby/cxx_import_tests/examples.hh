#ifndef TEST_HEADER_DATA_EXAMPLES_H
#define TEST_HEADER_DATA_EXAMPLES_H

#include <stdint.h>

namespace examples {

    struct MultiArrayStruct {
        int array[2][2];
    };

}


#endif /*TEST_HEADER_DATA_EXAMPLES_H*/
