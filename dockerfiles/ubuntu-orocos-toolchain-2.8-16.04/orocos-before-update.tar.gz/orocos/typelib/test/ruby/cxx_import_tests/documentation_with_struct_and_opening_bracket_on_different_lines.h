/* this is a multiline
 * documentation block
 */
struct DocumentedType
{
    int field; // otherwise the type is ignored
};
