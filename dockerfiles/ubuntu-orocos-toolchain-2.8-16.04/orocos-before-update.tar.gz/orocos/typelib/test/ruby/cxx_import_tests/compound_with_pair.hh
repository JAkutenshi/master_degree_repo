#ifndef TEST_HEADER_COMPOUND_WITH_PAIR
#define TEST_HEADER_COMPOUND_WITH_PAIR

#include <utility>

namespace ns_compound_with_pairs {

// lets see how this will work out...
class TestClass {
  public:
    std::pair<double, double> member;
};
}

#endif /*TEST_HEADER_DATA_CLASSES_H*/
