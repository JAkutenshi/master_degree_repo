struct Base
{
private:
    double first;
};

struct Derived : public Base
{
    double second;
};

