#ifndef TEST_HEADER_DATA_STDHEADERS_H
#define TEST_HEADER_DATA_STDHEADERS_H

#include <sys/time.h>
#include <time.h>
#include <stdint.h>

// Cannot import stdio.h: forward declarations
// #include <stdio.h>

// Cannot import stdlib.h: nested type definitions
// #include <stdlib.h>

#endif /*TEST_HEADER_DATA_STDHEADERS_H*/
