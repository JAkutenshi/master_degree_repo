/* this is a 香 multiline with ነ unicode characters
 */
struct DocumentedType
{
    int field; // otherwise the type is ignored
};
