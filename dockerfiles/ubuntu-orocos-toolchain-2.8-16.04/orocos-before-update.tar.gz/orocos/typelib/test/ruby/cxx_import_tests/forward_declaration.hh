#ifndef TEST_HEADER_DATA_FORWARD_DECLARATION_H
#define TEST_HEADER_DATA_FORWARD_DECLARATION_H

namespace ns {

    struct ForwardDeclaration;

    struct ForwardDeclaration {
        int a;
        int b;
    };
}

#endif /*TEST_HEADER_DATA_FORWARD_DECLARATION_H*/
