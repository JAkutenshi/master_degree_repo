struct Class
{
    virtual int method();
    double field;
};
