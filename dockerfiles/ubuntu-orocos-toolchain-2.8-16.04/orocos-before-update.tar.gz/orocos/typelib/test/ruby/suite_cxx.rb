require_relative './test_cxx'
require_relative './test_cxx_clang'
require_relative './test_cxx_castxml'
require_relative './test_cxx_gccxml'
