#include "import.hh"
#include "export.hh"
#include <typelib/plugins.hh>

TYPELIB_REGISTER_IO2(tlb, TlbExport, TlbImport)

