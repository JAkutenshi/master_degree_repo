                    if test -n "$AUTOPROJ_CURRENT_ROOT" && test "$AUTOPROJ_CURRENT_ROOT" != "/root/orocos"; then
                        echo "the env.sh from $AUTOPROJ_CURRENT_ROOT is already loaded. Start a new shell before sourcing this one"
                        return
                    fi
. "/root/orocos/.autoproj/env.sh"
unset GEM_PATH
AUTOPROJ_CURRENT_ROOT="/root/orocos"
export AUTOPROJ_CURRENT_ROOT
GEM_HOME="/root/.autoproj/gems/ruby/2.3.0"
export GEM_HOME
BUNDLE_GEMFILE="/root/orocos/install/gems/Gemfile"
export BUNDLE_GEMFILE
PYTHONUSERBASE="/root/orocos/install/pip"
export PYTHONUSERBASE
TYPELIB_CXX_LOADER="castxml"
export TYPELIB_CXX_LOADER
OROCOS_TARGET="gnulinux"
export OROCOS_TARGET
TYPELIB_USE_GCCXML="1"
export TYPELIB_USE_GCCXML
if test -z "$PATH"; then
  PATH="/root/orocos/install/bin:/root/orocos/.autoproj/bin"
else
  PATH="/root/orocos/install/bin:/root/orocos/.autoproj/bin:$PATH"
fi
export PATH
if test -z "$RUBYLIB"; then
  RUBYLIB="/root/.autoproj/gems/ruby/2.3.0/gems/rake-12.3.1/lib:/root/.autoproj/gems/ruby/2.3.0/gems/equatable-0.5.0/lib:/root/.autoproj/gems/ruby/2.3.0/gems/tty-color-0.4.2/lib:/root/.autoproj/gems/ruby/2.3.0/gems/pastel-0.7.2/lib:/root/.autoproj/gems/ruby/2.3.0/gems/necromancer-0.4.0/lib:/root/.autoproj/gems/ruby/2.3.0/extensions/x86_64-linux/2.3.0/hitimes-1.2.6:/root/.autoproj/gems/ruby/2.3.0/gems/hitimes-1.2.6/lib:/root/.autoproj/gems/ruby/2.3.0/gems/timers-4.1.2/lib:/root/.autoproj/gems/ruby/2.3.0/gems/tty-cursor-0.5.0/lib:/root/.autoproj/gems/ruby/2.3.0/gems/tty-screen-0.6.4/lib:/root/.autoproj/gems/ruby/2.3.0/gems/wisper-2.0.0/lib:/root/.autoproj/gems/ruby/2.3.0/gems/tty-reader-0.2.0/lib:/root/.autoproj/gems/ruby/2.3.0/gems/tty-prompt-0.15.0/lib:/root/.autoproj/gems/ruby/2.3.0/gems/facets-3.1.0/lib/standard:/root/.autoproj/gems/ruby/2.3.0/gems/facets-3.1.0/lib/core:/root/.autoproj/gems/ruby/2.3.0/gems/utilrb-3.0.1/lib:/root/.autoproj/gems/ruby/2.3.0/gems/autobuild-1.13.0/lib:/root/.autoproj/gems/ruby/2.3.0/gems/backports-3.11.3/lib:/root/.autoproj/gems/ruby/2.3.0/gems/concurrent-ruby-1.0.5/lib:/root/.autoproj/gems/ruby/2.3.0/extensions/x86_64-linux/2.3.0/ffi-1.9.23:/root/.autoproj/gems/ruby/2.3.0/gems/ffi-1.9.23/lib:/root/.autoproj/gems/ruby/2.3.0/gems/rb-inotify-0.9.10/lib:/root/.autoproj/gems/ruby/2.3.0/gems/thor-0.20.0/lib:/root/.autoproj/gems/ruby/2.3.0/gems/tty-spinner-0.8.0/lib:/root/.autoproj/gems/ruby/2.3.0/gems/autoproj-2.6.0/lib"
else
  RUBYLIB="/root/.autoproj/gems/ruby/2.3.0/gems/rake-12.3.1/lib:/root/.autoproj/gems/ruby/2.3.0/gems/equatable-0.5.0/lib:/root/.autoproj/gems/ruby/2.3.0/gems/tty-color-0.4.2/lib:/root/.autoproj/gems/ruby/2.3.0/gems/pastel-0.7.2/lib:/root/.autoproj/gems/ruby/2.3.0/gems/necromancer-0.4.0/lib:/root/.autoproj/gems/ruby/2.3.0/extensions/x86_64-linux/2.3.0/hitimes-1.2.6:/root/.autoproj/gems/ruby/2.3.0/gems/hitimes-1.2.6/lib:/root/.autoproj/gems/ruby/2.3.0/gems/timers-4.1.2/lib:/root/.autoproj/gems/ruby/2.3.0/gems/tty-cursor-0.5.0/lib:/root/.autoproj/gems/ruby/2.3.0/gems/tty-screen-0.6.4/lib:/root/.autoproj/gems/ruby/2.3.0/gems/wisper-2.0.0/lib:/root/.autoproj/gems/ruby/2.3.0/gems/tty-reader-0.2.0/lib:/root/.autoproj/gems/ruby/2.3.0/gems/tty-prompt-0.15.0/lib:/root/.autoproj/gems/ruby/2.3.0/gems/facets-3.1.0/lib/standard:/root/.autoproj/gems/ruby/2.3.0/gems/facets-3.1.0/lib/core:/root/.autoproj/gems/ruby/2.3.0/gems/utilrb-3.0.1/lib:/root/.autoproj/gems/ruby/2.3.0/gems/autobuild-1.13.0/lib:/root/.autoproj/gems/ruby/2.3.0/gems/backports-3.11.3/lib:/root/.autoproj/gems/ruby/2.3.0/gems/concurrent-ruby-1.0.5/lib:/root/.autoproj/gems/ruby/2.3.0/extensions/x86_64-linux/2.3.0/ffi-1.9.23:/root/.autoproj/gems/ruby/2.3.0/gems/ffi-1.9.23/lib:/root/.autoproj/gems/ruby/2.3.0/gems/rb-inotify-0.9.10/lib:/root/.autoproj/gems/ruby/2.3.0/gems/thor-0.20.0/lib:/root/.autoproj/gems/ruby/2.3.0/gems/tty-spinner-0.8.0/lib:/root/.autoproj/gems/ruby/2.3.0/gems/autoproj-2.6.0/lib:$RUBYLIB"
fi
export RUBYLIB
if test -z "$CMAKE_PREFIX_PATH"; then
  CMAKE_PREFIX_PATH="/root/orocos/install"
else
  CMAKE_PREFIX_PATH="/root/orocos/install:$CMAKE_PREFIX_PATH"
fi
export CMAKE_PREFIX_PATH
. "/root/.autoproj/gems/ruby/2.3.0/gems/autoproj-2.6.0/shell/autoproj_sh"
