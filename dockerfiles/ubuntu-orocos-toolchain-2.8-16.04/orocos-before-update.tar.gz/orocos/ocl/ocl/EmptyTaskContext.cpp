
#include <rtt/TaskContext.hpp>
#include "Component.hpp"

using namespace RTT;

ORO_LIST_COMPONENT_TYPE( TaskContext )
