/* Put any C/C++ code in here which you want as a separate library */

