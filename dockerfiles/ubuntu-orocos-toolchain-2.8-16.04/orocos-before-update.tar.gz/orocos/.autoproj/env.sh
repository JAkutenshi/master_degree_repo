unset RUBYLIB
unset GEM_PATH
unset BUNDLE_GEMFILE
GEM_HOME="/root/.autoproj/gems/ruby/2.3.0"
export GEM_HOME
if test -z "$PATH"; then
  PATH="/root/orocos/.autoproj/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
else
  PATH="/root/orocos/.autoproj/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:$PATH"
fi
export PATH
